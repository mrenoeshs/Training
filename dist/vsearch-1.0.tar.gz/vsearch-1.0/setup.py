from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    desctiption='The Head First Python Seach Tools',
    author='Steven Eno',
    author_email='steven.e.eno@gmail.com',
    url='enovationproductions.com',
    py_modules=['vsearch'],
)